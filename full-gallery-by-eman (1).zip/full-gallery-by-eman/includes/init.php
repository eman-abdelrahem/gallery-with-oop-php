<?php


   defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);

   define('SITE_ROOT', DS .'opt'. DS. 'lampp'. DS. 'htdocs'.DS.'gellry');
   defined('INCLUDES_PATH' ) ? null : define('INCLUDES_PATH', SITE_ROOT . DS. 'admin'.DS. 'includes');

    defined('IMAGES_PATH') ? null : define('IMAGES_PATH', SITE_ROOT.DS.'admin'.DS.'images');

  require_once("./admin/includes/functions.php");
  require_once("./admin/includes/new_config.php");
  require_once("./admin/includes/database.php");
  require_once("./admin/includes/db_object.php");
  require_once("./admin/includes/user.php");
  require_once("./admin/includes/photo.php");
  require_once("./admin/includes/comment.php");
  require_once("./admin/includes/session.php");
  require_once("./admin/includes/paginate.php");



?>
