<?php include("includes/header.php"); ?>
<?php include("includes/photo_library_modal.php"); ?>


<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>

<?php 


if(empty($_GET['id'])) {

    redirect("users.php");

    } 
    else {


    $user = User::find_all_by_id($_GET['id']);

              
                if(isset($_POST['update'])) {

                if($user) {

                $user->username  =$_POST['username'];
                $user->password  = $_POST['password'];
                $user->firstname = $_POST['firstname'];
                $user->lastname  = $_POST['lastname'];

                if(empty($_FILES['user_image'])){
                    
                    $user->save();
                    redirect("users.php");
                $session->message("the user has been updated");

                }

                else{
                    
                     $user->set_file($_FILES['user_image']);
                     $user->save_user_and_image();
                     $user->save();
                    $session->message("the user has been updated");


                    // redirect("edit_user.php?id={$user->id}");
                    redirect("users.php");

                }

              

                }
                }

                }

            
 ?>




        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->



        <?php include("includes/top_nav.php") ?>





            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
           

    
        <?php include("includes/side_nav.php"); ?>




            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">


            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header col-md-offset-3">
                           Edit User
                            <small>Subheading</small>
                        </h1>
                        <div class="col-md-6 user_image_box">
                        <a href="#" data-toggle="modal" data-target="#photo-library">
                 
                   <img class="admin-photo-thumbnail"src="<?php echo $user->image_path_and_placeholder();?>" alt="" >
                   </a>
                </div>

                    <form action="" method="post" enctype="multipart/form-data">

                        <div class="col-md-6">
                             
                        <input type="file" name="user_image">
                        <br>

                           <div class="form-group">
                           <label for="username">username</label>
                            <input type="text" name="username" class="form-control" value="<?php echo $user->username ?>">
                                </div>

                            <div class="form-group">
                                <label for="password">password</label>
                            <input type="password" name="password" class="form-control" value="<?php echo $user->password ?>" >
                               
                           </div>

                            <div class="form-group">
                                <label for="firstname">firstname</label>
                            <input type="text" name="firstname" class="form-control" value="<?php echo $user->firstname?>" >
                               
                           </div>
                           <div class="form-group">
                                <label for="lastname">lastname</label>
                            <input type="text" name="lastname" class="form-control" value="<?php echo $user->lastname ?>" >
                               
                           </div>


                           <div class="info-box-footer clearfix">
                                <div class="info-box-delete pull-left">
                                    <a id="user-id" class="btn btn-danger btn-lg" href="delete_user.php?id=<?php echo $user->id; ?>" class="btn btn-danger btn-lg">Delete</a>   
                                </div>
                                <div class="info-box-update pull-right ">
                                    <input type="submit" name="update" value="update" class="btn btn-primary btn-lg ">
                                </div>   
                              </div>
                        </div>


                            </div>          
                        </div>
                    </div>


            </form>




                        
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

  <?php require_once("includes/footer.php"); ?>