<?php include("includes/init.php"); ?>

<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>

<?php 
 $message="";

if(empty($_GET['id'])) {
  // $message = "The {$user->filename} has been deleted";

redirect("users.php");
}

$comment = comment::find_all_by_id($_GET['id']);

if($comment) {

$comment->delete();
$session->message("The comment with id= {$comment->id} has been deleted");
redirect("comments.php");


}
 else {

redirect("comments.php");


}










 ?>