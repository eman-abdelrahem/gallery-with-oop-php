<?php require_once("includes/header.php"); ?>
<?php if(!$session->is_signed_in()) {redirect("login.php");} ?>


<?php 

$message = "";
if(isset($_FILES['file'])) { 

$photo = new Photo();

//$photo->user_id = $_SESSION['user_id'];
$photo->title = $_POST['title'];
$photo->set_file($_FILES['file']);

if($photo->save()) {

$message = "Photo {$photo->filename} uploaded sucessfully"; 


} else {

$message = join("<br>", $photo->errors);


}

}

 ?>



        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">SB Admin</a>
            </div>
            <!-- Top Menu Items -->
                 <?php include("includes/top_nav.php"); ?>



            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php include("includes/side_nav.php"); ?>

            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

          <div class="container-fluid">

              <!-- Page Heading -->
              <div class="row">
                  <div class="col-lg-12">
                      <h1 class="page-header">
                        Upload
                          <small>photos</small>
                      </h1>

          <div class="row">
                      <div class="col-md-6">
                      <?php echo $message ; ?>
                      <form action="upload.php" method="post" enctype = "multipart/form-data">
	
                         <div class="form-group">
                             <input type="text" name="title" class="form-control">
                         </div>
                         
                         <div class="form-group">
                             <input type="file" name="file">
                         </div>

                         <input type="submit" name="submit">
    
    </form>
    </div>
    </div>

  <hr>
    <div class="row">
    
    <div class="col-lg-12">
    <form action="upload.php" class="dropzone">

    <div class="form-group col-md-6">
                   <label for="title" > One Title for all files</label>
                             <input type="text" name="title" class="form-control">
                         </div>
                        
    
    
    </form>
    
    
    
    
    </div>
    
    
    </div>












                      <ol class="breadcrumb">
                          <li>
                              <i class="fa fa-dashboard"></i>  <a href="index.php">Dashboard</a>
                          </li>
                          <li class="active">
                              <i class="fa fa-file"></i> Blank Page
                          </li>
                      </ol>
                  </div>
              </div>
              <!-- /.row -->

          </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

  <?php include("includes/footer.php"); ?>
