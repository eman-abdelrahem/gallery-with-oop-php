
<?php

   require_once("new_config.php");

     class Database{
        public $conn;
        
        public $db;
        function __construct(){

           $this->db =$this->connect();

        }

         public function connect(){
           
       $this->conn = new mysqli(DB_HOST,DB_USER,DB_PASS, DB_NAME);

       if ($this->conn->connect_errno){
             die("OPPS, connection faild").$this->conn->error;

          }
          return $this->conn;

     }

     public function query($sql){
       $result = $this->db->query($sql);

        // $this->conn->confirm_query($result);

       return $result;
     }

  public function confirm_query($result){

    if(!$result){
      die("OPPS"). $this->db->connect_error;
    }

  }

    public function escape_string($string){

      return $this->db->real_escape_string($string);
    }

     public function insert_id(){

          return $this->db->insert_id;
     }

     public function insert_username(){

      return $this->db->insert_id;
 }


   }



     $database = new Database();
?>
